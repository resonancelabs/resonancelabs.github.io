// Usage:
//      require("cruntime-node")
// 
// Will import the cruntime-node library and automatically start the 
// reporting loop.

var lib = require("./src/cruntime_node.js");
var packageObject = require("./package.json");

lib.initialize({
    cruntime_platform   : packageObject.name,
    cruntime_version    : packageObject.version,
});

module.exports = lib;
