//===========================================================================//
// Dependencies
//===========================================================================//

var assert      = require("chai").assert,
    _           = require("underscore"),
    commonTests = require("node/packages/rl-cruntime-common/test/shared_unittests.js");

// Import cruntime in "paused" mode as we don't want to explicitly control
// the reporting for testing purposes.
var cr      = require("../paused");


//===========================================================================//
// Common Tests
//===========================================================================//

commonTests(cr, assert, _);

//===========================================================================//
// Node-specific tests
//===========================================================================//

// None at the moment!
