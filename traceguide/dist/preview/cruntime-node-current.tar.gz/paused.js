// Usage:
//      require("cruntime-node/paused")
// 
// Will import the cruntime-node library without automatically starting
// the reporting loop.

var lib = require("./src/cruntime_node.js");
var packageObject = require("./package.json");

lib.initialize({
    paused              : true,
    cruntime_platform   : packageObject.name,
    cruntime_version    : packageObject.version,
});

module.exports = lib;