var rbuild  = require("node/tools/rbuild"),
    path    = require("path");

var plugins = rbuild.Plugins;
var build = new rbuild.Build();

var repoDir = path.normalize(path.join(process.env.GOPATH, ".."));
var publishDir = path.join(repoDir, "/static/resonancelabs.github.io/traceguide/dist/preview/");
var croutonThriftFilename = path.join(repoDir, "go/src/crouton", "crouton.thrift");

build.task("build")
    .deps("thrift");

build.task("test")
    .describe("unit tests")
    .deps("build", "lint")
    .spawn("node node_modules/mocha/bin/mocha");

build.task("test-watch")
    .describe("automatically rerun tests on file changes")
    .watch()
    .deps("lint", "test")
    .sources([
        "index.js",
        "src/**/*.js",
        "test/**/*.js",
        repoDir + "/node/packages/rl-cruntime-common/**/*.js",
    ]);

build.task("thrift")
    .describe("generates the node.js thrift code")
    .sources(croutonThriftFilename)
    .spawn("thrift -r -gen js:node -out src/generated", croutonThriftFilename);

build.task("lint")
    .describe("run jshint on the source")
    .sources("src/*.js")
    .template(plugins.jshint);

//
// Publish a distributable package to resonancelabs.github.io
//
// TODO: eventually copy a cruntime-node-x.x.x.tar.gz as well as 
// updating "-current.tar.gz".
//
build.task("publish")
    .describe("copies the current code to the public distribution")
    .deps("publish-deps", "publish-copy", "publish-commit")

build.task("publish-deps")
    .action(function(ctx) {
        ctx.rbuild(repoDir + "/node/packages/rl-cruntime-common", "publish", function() {
            ctx.complete();
        });
    });
    
build.task("publish-copy")
    .command("git ls-files | tar cfz dist/cruntime-node-current.tar.gz -T -")
    .spawn("cp", "dist/cruntime-node-current.tar.gz", publishDir);

build.task("publish-commit")
    .cwd(publishDir)
    .spawn("git add .")
    .spawn(["git", "commit", "-m", "'publish cruntime-node'"])
    .spawn("git push origin master");


build.start("build");
