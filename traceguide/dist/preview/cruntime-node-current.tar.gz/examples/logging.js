// Manual test for logging
var cr = require("..");

/*cr.init({
    override_console : true,
    join_ids : {
        end_user_id     : "cruntime_test_logging",
    },
});*/

cr.options({ 
    override_console : true 
});

cr.info("A regular info log");
cr.info("Log", "multiple", "strings");
cr.info("Log numbers", 1, 2, 3, 4);
cr.info("Log an array", [ 1, 2, 3, ]);
cr.info("Log an object", { obj : [ 1, 2, 3] });
cr.warn("Log a warning message.");
cr.error("Log an error message!");

console.log("This is a regular console log.");
console.warn("This is a regular console warning.");
console.error("This is a regular console error.");

cr.info("cruntime buffer:", cr.stats());

setInterval(function() {
    cr.info("Hello", new Date());
}, 2500);

setInterval(function() {
    cr.error("Random Error!");
}, Math.random() * 10000);

(function loop() {
    var activeSpan = cr.span("test loop");
    activeSpan.info("Starting test span", new Date());

    var lengthMs = Math.floor(50 + 5000 * Math.random());
    if (lengthMs > 2000) {
        activeSpan.warn("Length of greater than 2 seconds!", lengthMs);
    }

    var delayMs = Math.floor(50 + 1000 * Math.random());
    activeSpan.info("Delay of", delayMs);

    setTimeout(function() {
        activeSpan.info("Completed test span");
        activeSpan.end();
        setTimeout(loop, delayMs);
    }, lengthMs);
})();
