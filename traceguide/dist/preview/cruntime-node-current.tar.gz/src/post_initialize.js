// This function is run as soon as cruntime is initialized

var cruntimePackageJSON = require("../package.json");

module.exports = function postInitialize(cr) {
    cr.event("cruntime_node.initialized", cruntimePackageJSON);

    require("./instrument_http.js")(cr);
    require("./instrument_express.js")(cr);
    require("./initialize_monitoring.js")(cr);
};
