var path    = require("path"),
    util    = require("util"),
    _       = require("underscore");


// Try to load a module and return the loaded module, its package.json, and
// the path it was found at.
//
module.exports.tryRequiringPackage = function (packageName) {
    // Assume that the package that wants to be instrumented has
    // included cruntime directly, so jump back one level of the
    // node_modules installation.  This flat-out assumes a conventional
    // dependency inclusion.  If there's a more robust way to do this,
    // that would be great, but it's not clear that there is...
    var paths = [
        "../../" + packageName,
        "../../../node_modules/" + packageName,
        "../" + packageName,
        "../../node_modules/" + packageName,
        path.join(process.cwd(), "node_modules", packageName)
    ];
    for (var i = 0; i < paths.length; i++) {
        var pkgPath = paths[i];
        try {
            var pkg = require(pkgPath);
            var info = require(pkgPath + "/package.json");
            return {
                package  : pkg,
                metadata : info,
                path     : pkgPath,
            };
        } catch (e) {
            // Ignore and fall through
        }
    }
    return null;
};

module.exports.toPayloadValue = function (data) {
    // Try parsing as JSON
    if (typeof data === "string") {
        try {
            data = JSON.parse(data);
        } catch (e) {
        }
    }

    return util.inspect(data);
};
