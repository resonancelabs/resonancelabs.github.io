//===========================================================================//
// Dependencies
//===========================================================================//

var util            = require("util"),
    _               = require("underscore"),
    colors          = require("colors/safe");

//===========================================================================//
// Globals
//===========================================================================//

var lib = {};

//===========================================================================//
// Internal helpers
//===========================================================================//

function prefix(c) {
    var now = new Date();
    var h = now.getHours();
    var m = now.getMinutes();
    var s = now.getSeconds();
    var h0 = (h < 10) ? "0" : "";
    var m0 = (m < 10) ? "0" : "";
    var s0 = (s < 10) ? "0" : "";
    return c + 
        h0 + h + 
        ":" + m0 + m + 
        "." + s0 + s +
        "]";
}

function format(args) {
    args = Array.prototype.slice.call(args);
    var s = "";
    var i;
    for (i = 0; i < args.length; i++) {
        
        if (_.isObject(args[i]) || _.isNumber(args[i])) {
            s += util.inspect(args[i], { depth : 2, colors : lib.useColors });
        } else {
            s += args[i].toString();
        }
        
        if (i + 1 < args.length) {
            s += " ";
        }
    }
    return s;
}

//===========================================================================//
// Exported configuration
//===========================================================================//

// Copy the console methods locally in case the global object gets overridden.
lib.console = {
    log   : console.log,
    warn  : console.warn,
    error : console.error,
};
lib.useColors = true;

//===========================================================================//
// Exported API
//===========================================================================//

lib.fmt = function() {
    return format(args);
};

lib.info = function(args) {
    var p = prefix("I");
    if (lib.useColors) {
        p = colors.gray(p);
    }
    lib.console.log(p + " " + format(args));
};

lib.warn = function(args) {
    var p = prefix("W");
    if (lib.useColors) {
        p = colors.yellow.bold(p);
    }
    lib.console.warn(p + " " + format(args));
};

lib.error = function(args) {
    var p = prefix("E");
    if (lib.useColors) {
        p = colors.red.bold(p);
    }
    lib.console.error(p + " " + format(args));
};

lib.fatal = function(args) {
    var text = format(args);
    
    var p = prefix("F");
    if (lib.useColors) {
        p = colors.bgRed.yellow.bold(p);
    }
    
    var stack = new Error(text).stack;
    lib.console.error(p + " " + text + "\n" + stack);
};

module.exports = lib;
