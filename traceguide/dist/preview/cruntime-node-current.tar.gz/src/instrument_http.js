var http    = require("http"),
    util    = require("util"),
    Buffer  = require("buffer"),
    helpers = require("./helpers.js"),
    _       = require("underscore");

module.exports = function (cr) {
    if (!http.ServerResponse) {
        return;
    }

    // Hook into http.Server, which creates the ServerResponse objects.
    // Use the "request" event to start the span.
    var proxiedCreateServer = http.createServer;
    http.createServer = function() {
        cr.log("http.createServer called");
        var server = proxiedCreateServer.apply(this, arguments);
        server.on("request", function(req, res) {
            res.__cr_span = cr.span("http.request");
            res.on("close", function() {
                res.__cr_span.end();
            });
        });
        return server;
    };

    // Use the ServerResponse object to hook into the send data.
    var protoResp = http.ServerResponse.prototype;
    var proxiedResp = {
        writeHead   : protoResp.writeHead,
        write       : protoResp.write,
        end         : protoResp.end,
    };
    protoResp.writeHead = function(statusCode, statusMessage, headers) {
        var span = this.__cr_span || cr;
        span.event("http.ServerResponse.writeHead", {
            status_code     : statusCode,
            status_message  : statusMessage,
            headers         : headers,
        });
        return proxiedResp.writeHead.apply(this, arguments);
    };

    protoResp.write = function (chunk, encoding, callback) {
    
        var span = this.__cr_span || cr;
        span.event("http.ServerResponse.write", {
            data : helpers.toPayloadValue(chunk),
        });
        return proxiedResp.write.apply(this, arguments);
    };
    protoResp.end = function(data, encoding, callback) {
        var span = this.__cr_span || cr;
        span.event("http.ServerResponse.end", {
            data : helpers.toPayloadValue(data),
        });
        var ret = proxiedResp.end.apply(this, arguments);
        span.end();
        return ret;
    };
};