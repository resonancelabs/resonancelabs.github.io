
// TODO: the polling interval should be configurable
var kPollingInterval = 2500;

module.exports = function(cr) {

    (function poll() {
        cr.event("cruntime.process.monitoring", {
            process_id    : process.id,
            process_title : process.title,
            uptime        : process.uptime(),
            arch          : process.arch,
            platform      : process.platform,
            environment   : process.env,
            argv          : process.argv,
            node_version  : process.version,
            node_versions : process.versions,
            node_config   : process.config,
            memory_usage  : process.memoryUsage(),
        });
        setTimeout(poll, kPollingInterval);
    })();
};