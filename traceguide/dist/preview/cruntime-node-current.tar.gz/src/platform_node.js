// Platform-specific functions to encapsulate the differences from crutinme-common

var lib = {};

lib.isNode = true;

lib.console = console;

lib.nowMicros = (function() {
    var startTimeMs = Date.now();
    var startHrTime = process.hrtime();
    var baseHrMicros = (startHrTime[0] * 1000000.0 + startHrTime[1] / 1000.0);

    var startTimeMicros = (startTimeMs * 1000.0) - baseHrMicros;        
    return function() {
        var hrTime = process.hrtime();
        return Math.floor(startTimeMicros + hrTime[0] * 1000000.0 + hrTime[1] / 1000.0);
    };
})();

// Low-quality GUID: this is just a 53-bit random integer! (53 bits since the
// backing store for the number is a 64-bit float).
lib.generateGUID = function() {
    return Math.floor(Math.random() * 9007199254740992).toString(10);
};

lib.logger = require("./log.js");

lib.abort = function() {
    process.abort();
};

lib.stackTrace = function() {
    var stack = new Error().stack;
    if (typeof stack === "string") {
        stack = stack.split("\n").slice(3);
        for (var i = 0; i < stack.length; i++) {
            stack[i] = stack[i].replace(/^\s*at\s+/, "");
        }
        return stack;
    } else {
        return undefined;
    }
};

// Returns the placeholder for the filename in a log record.
lib.defaultLogFilename = (function() {
    var name = "<node " + process.version + 
        "-" + process.platform + 
        "-" + process.arch + ">";
    return function() {
        return name;
    };
})();

module.exports = lib;

