var helpers = require("./helpers.js");

module.exports = function (cr) {
    var pkg = helpers.tryRequiringPackage("express");
    if (!pkg) {
        return;
    }
    
    cr.log("Found express version: ", pkg.metadata.version);
    var express = pkg.package;

    if (!express.application) {
        return;
    }

    // TODO: the express API is very dynamic and based on context.  This is 
    // currently *not* hooking in at the bottleneck point where all handlers can
    // be instrumented.  This is getting a common case Wren uses working as a 
    // starting point!  We should probably be injected into the Router object
    // instead.
    var proxied = express.application.post;
    express.application.post = function(url, handler) {
        if (typeof url === "string" && typeof handler === "function" && arguments.length == 2) {
            var proxiedHandler = handler;
            handler = function(req, res, next) {
                var span = cr.span("express.post:" + url);
                span.event("express.post:" + url, {
                    protocol    : req.protocol,
                    hostname    : req.hostname,
                    method      : req.method,
                    headers     : req.headers,
                });

                // TODO: not sure how error-proof this is. Is send() the *only* way a 
                // request can be closed in express?
                var proxiedSend = res.send;
                res.send = function(data) {
                    span.event("express.res.send", {
                        data : helpers.toPayloadValue(data),
                    });
                    span.end();
                    return proxiedSend.apply(this, arguments);
                };
                return proxiedHandler.apply(this, arguments);
            };
        }
        return proxied.apply(this, arguments);
    };
};
