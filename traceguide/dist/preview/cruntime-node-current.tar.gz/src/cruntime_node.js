//===========================================================================//
// Export
//===========================================================================//

var common = require("node/packages/rl-cruntime-common");

var state = common.createState({
    thriftTypes     : require("./thrift_wrapper.js"),
    thriftLibrary   : require("thrift"),
    platform        : require("./platform_node.js"),
    groupName       : "cruntime_node",
    postInitialize  : require("./post_initialize.js"),
});

module.exports = common.api(state);
