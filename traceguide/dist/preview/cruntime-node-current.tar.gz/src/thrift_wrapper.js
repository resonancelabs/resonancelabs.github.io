// The thrift 0.9.2 generates a set of files, but not a valid NPM package.
// (Why? What am I missing?)  This file merges the symbols into a single
// namespace.
// 

module.exports = require("./generated/crouton_types.js");

// Merge in the service objects and rename them to be consistent with
// the browser-side JS.
var service = require("./generated/CroutonService.js");
module.exports.CroutonServiceClient = service.Client;
module.exports.CroutonServiceProcessor = service.Processor;
