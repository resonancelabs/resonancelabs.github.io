// Independent node script to issue a single http(s).request().
// 
// This is designed for the single use case of a final, synchronous RPC before process
// exit of the node.js cruntime -- not as a generalized command-line http request 
// implementation. 
//
// The first argument should be a base64-encoded JSON string including the "https" 
// boolean and "nodeOptions" object (as set by in the thrift v0.9.2 NPM HttpConnection 
// class). The second argument is the base64 binary buffer of the request body.
//
var self = JSON.parse((new Buffer(process.argv[2], "base64")).toString("utf8"));
var dataFilename = process.argv[3];
var data = require("fs").readFileSync(dataFilename);
require("fs").unlinkSync(dataFilename);

self.nodeOptions.headers["Content-length"] = data.length;
var req = (self.https) ?
    require("https").request(self.nodeOptions, done) :
    require("http").request(self.nodeOptions, done); 
req.on("error", function(err) {
    process.exit(1);
});
req.write(data);
req.end();

function done(res) {
    process.exit(0);
}
