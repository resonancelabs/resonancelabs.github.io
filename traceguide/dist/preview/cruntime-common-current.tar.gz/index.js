//===========================================================================//
// Dependencies
//===========================================================================//

var State = require("./src/state.js");

//===========================================================================//
// Exported API
//===========================================================================//

var lib = {};

// Creates the "state" object which contains the core functionality of the 
// client library including the buffering and all raw/low-level logging and 
// span calls which the platform-dependent code can call.  The platform 
// libraries are intended to be slim wrappers on this State object.
//
// The "opts" argument passes in all the platform-dependent hooks and 
// information.
//
lib.createState = function(opts) {
    
    // Check that the necessary thrift connection points are there
    if (!opts.thriftTypes) {
        throw new Error("opts.thriftTypes required");
    }
    if (!opts.thriftLibrary) {
        throw new Error("opts.thriftLibrary required");
    }

    // Check that our pal, the platform abstraction layer, is fully 
    // specified.
    if (!opts.platform) {
        throw new Error("opt.platform required");
    }
    if (typeof opts.platform.nowMicros !== "function") {
        throw new Error("nowMicros is a required platform function");
    }
    if (typeof opts.platform.generateGUID !== "function") {
        throw new Error("generateGUID is a required platform function");
    }
    if (typeof opts.platform.console !== "object") {
        throw new Error("console is not a valid platform object");
    }
    if (typeof opts.platform.console.log !== "function") {
        throw new Error("console.log is not a valid platform function");
    }
    if (typeof opts.platform.console.warn !== "function") {
        throw new Error("console.warn is not a valid platform function");
    }
    if (typeof opts.platform.console.error !== "function") {
        throw new Error("console.error is not a valid platform function");
    }

    // Required cruntime configuration
    if (typeof opts.groupName !== "string") {
        throw new Error("opts.groupName is not a valid string");
    }

    return new State(
        opts.thriftTypes, 
        opts.thriftLibrary, 
        opts.platform, 
        opts.groupName, 
        opts.postInitialize
    );
};

lib.api = require("./src/api.js");

module.exports = lib;
