//
// A set of unit tests that should pass both in node and the browser.
//
module.exports = function(cr, assert, _) {

    //===========================================================================//
    // Testing stubs
    //===========================================================================//

    var stub = {
        console    : [],
        requests   : [],
        abortCount : 0,
    };

    function enableTestStub() {
        cr.options({
            override_abort : function() {
                stub.abortCount++;
            },

            override_logger : function() {
                stub.console.push(_.toArray(arguments));
            },

            override_report_rpc : function(synchronous, req, done) {

                var guids = {};
                _.each(req.span_records, function(record) {
                    assert.isNotNull(record.span_guid);

                    assert.notEqual(guids[record.span_guid], true, "Duplicate span GUID in report");
                    guids[record.span_guid] = true;
                });

                // Deep clone the request object via a JSON round-trip
                stub.requests.push(JSON.parse(JSON.stringify(req)));
                if (synchronous) {
                    done();
                } else {
                    _.defer(done);
                }

            },
        });
    }
    function disableTestStub() {
        cr.options({
            override_abort      : null,
            override_logger     : null,
            override_report_rpc : null,
        });
    }
    function resetTestStubData() {
        cr.discard();
        stub.console = [];
        stub.requests = [];
        stub.abortCount = 0;
    }

    //===========================================================================//
    // Tests
    //===========================================================================//

    describe("API spec", function() {
        var expectedFunctions = [
            "initialize",

            "info",
            "infof",
            "warn",
            "warnf",
            "error",
            "errorf",
            "fatal",
            "fatalf",

            "span",
            "spanWrap",
            "spanSection",

            "event",
            "eventWrap",

            "stats",
            "status",
        ];
        _.each(expectedFunctions, function(name) {
            it("should have a function called " + name, function() {
                assert.typeOf(cr[name], "function");
            });
        });
    });

    describe("Logging", function() {

        describe("General", function() {

            before(enableTestStub);
            after(disableTestStub);
            beforeEach(resetTestStubData);            

            it("should not complain if no args are provided", function() {
                var verbs = [
                    "log",
                    "info",
                    "error"
                ];
                _.each(verbs, function(verb) {
                    assert.doesNotThrow(function() {
                        cr[verb]();
                    });
                });
            });

            it("should handle lots of log calls", function() {
                for (var i = 0; i < 4096; i++) {
                    cr.log("I prefer the number", i, "to", Math.random());
                }
                assert.equal(stub.console.length, 4096);
            });
        });

        describe("Console behavior", function() {

            before(enableTestStub);
            after(disableTestStub);
            beforeEach(resetTestStubData);

            it("should echo the text for all log types", function() {
                cr.info("Hello World");
                cr.warn("Hello World");
                cr.error("Hello World");

                assert.equal(stub.console.length, 3);
                assert.equal(stub.console[0][0], "Hello World");
                assert.equal(stub.console[1][0], "Hello World");
                assert.equal(stub.console[2][0], "Hello World");
            });

            it("should handle 0 arguments correctly", function() {
                assert.doesNotThrow(function() { cr.info(); });
                assert.doesNotThrow(function() { cr.warn(); });
                assert.doesNotThrow(function() { cr.error(); });

                assert.equal(stub.console.length, 3);
                assert.equal(stub.console[0].length, 1);
                assert.equal(stub.console[0][0], "");
                assert.equal(stub.console[1].length, 1);
                assert.equal(stub.console[1][0], "");
                assert.equal(stub.console[2].length, 1);
                assert.equal(stub.console[2][0], "");        
            });

            it("should join arguments with spaces", function() {
                cr.info("Hello", "World");
                cr.warn("Hello", "World");
                cr.error("Hello", "World");
                
                cr.info("A", "B", "C", "D");
                cr.warn("A", "B", "C", "D");
                cr.error("A", "B", "C", "D");

                cr.info(1, 2, 3, 4);
                cr.warn(1, 2, 3, 4);
                cr.error(1, 2, 3, 4);  

                assert.equal(stub.console.length, 9);
                assert.equal(stub.console[0][0], "Hello World");
                assert.equal(stub.console[1][0], "Hello World");
                assert.equal(stub.console[2][0], "Hello World");   
                assert.equal(stub.console[3][0], "A B C D");
                assert.equal(stub.console[4][0], "A B C D");
                assert.equal(stub.console[5][0], "A B C D");   
                assert.equal(stub.console[6][0], "1 2 3 4");
                assert.equal(stub.console[7][0], "1 2 3 4");
                assert.equal(stub.console[8][0], "1 2 3 4");
            });

            it("should handle fatal correctly", function() {
                cr.fatal();
                assert.equal(stub.abortCount, 1);

                cr.fatal();
                assert.equal(stub.abortCount, 2);

                cr.fatal("Something went wrong");
                assert.equal(stub.abortCount, 3);
                assert.equal(stub.console.length, 3);
            });
        });

        describe("RPC behavior", function() {

            before(enableTestStub);
            after(disableTestStub);
            beforeEach(resetTestStubData);

            it("should have one log record for each log statement", function() {
                cr.info("Hello World!");
                cr.info(42);
                cr.flush(true);

                assert.equal(stub.requests.length, 1);

                var req = _.first(stub.requests);
                assert.equal(req.log_records.length, 2);

                _.each(req.log_records, function (record) {
                    assert.typeOf(record.message, "string");
                    assert.isAbove(record.message.length, 0);
                });
            });

            it("should record all kinds of log statements", function() {
                cr.info("Info");
                cr.warn("Warning");
                cr.error("Error");
                cr.flush(true);

                assert.equal(stub.requests.length, 1);

                var req = _.first(stub.requests);
                assert.equal(req.log_records.length, 3);

                _.each(req.log_records, function (record) {
                    assert.typeOf(record.message, "string");
                    assert.isAbove(record.message.length, 0);
                });
            });

            it("should log exceptions with payload data", function() {
                cr.exception(new Error("This is an error"));
                try {
                    eval("123 syntax error");
                } catch (e) {
                    cr.exception(e);
                }
                cr.flush(true);

                assert.equal(stub.requests.length, 1);
                var req = _.first(stub.requests);
                assert.equal(req.log_records.length, 2);
                var record = req.log_records[0];
                assert.match(record.message, /Error/);
                assert.match(record.filename, /\.js$/i);
                assert.match(record.line_number, /[0-9]+/);
            });
        });
    });

    describe("Spans", function() {

        describe("span", function() {

            before(enableTestStub);
            after(disableTestStub);
            beforeEach(resetTestStubData);

            it("should return a valid span handle", function() {
                var handle = cr.span("test_span");
                assert.typeOf(handle.end, "function");
                assert.typeOf(handle.span, "function");
                assert.typeOf(handle.info, "function");
                assert.typeOf(handle.warn, "function");
                assert.typeOf(handle.error, "function");
                handle.end();
            });

            it("should record join ids correctly", function() {

                var h = cr.span("test_span", { key : "value" });
                h.end();
                cr.flush(true);

                assert.equal(stub.requests.length, 1);
                var req = stub.requests[0];

                assert.equal(req.span_records.length, 1);
                assert.equal(req.log_records.length, 0);
                var span = req.span_records[0];

                assert.equal(span.span_name, "test_span");
                assert.equal(span.join_ids.length, 1);
                assert.deepEqual(span.join_ids, [{
                    TraceKey : "key",
                    Value : "value",
                }]);
            });

            it("should handle nested spans", function() {

                cr.info("cr log statement");
                var h0 = cr.span("span0", { user : "person" });
                    h0.info("h0 log statement");
                    h0.event("h0.started");
                    var h1 = h0.span("span1");
                    h1.info("h1 info");
                    h1.warn("h1 warn");
                    h1.error("h1 error");
                        var h2 = h1.span("span2", { activity : "testing" });
                        h2.info("test", 123);
                        h2.warn("test", 234);
                        h2.error("test", 345);
                        var z;
                        h2.spanSection("compute", function() {
                            for (var i = 0; i <= 40; i ++) {
                                z = i + 2;
                            }
                        });
                        assert.equal(z, 42);
                        h2.end();
                    h1.end();
                    h0.event("finished", { sucess : true });
                h0.end();

                cr.flush(true);

                assert.equal(stub.requests.length, 1);
                var req = stub.requests[0];

                assert.equal(req.span_records.length, 4);
                var span = req.span_records[0]; 
            });

            it("should behave sanely when end() is called twice", function() {
                assert.doesNotThrow(function() {
                    var span = cr.span("my_span");
                    span.end();
                    span.end();
                });
            });
        });

        describe("spanWrap", function() {

            before(enableTestStub);
            after(disableTestStub);
            beforeEach(resetTestStubData);

            it("should return a valid function wrapper", function() {
                function mul() { return 21 * 2; }
                function add(a, b) { return a + b; }
                add = cr.spanWrap("span.add", {}, add);
                mul = cr.spanWrap("span.mul", {}, mul);

                var result = add(4, 2);
                assert.equal(result, 6);

                mul();
                mul();
                cr.flush(true);

                assert.equal(stub.requests.length, 1);

                var req = _.first(stub.requests);
                assert.lengthOf(req.log_records, 0);
                assert.lengthOf(req.span_records, 3); 
            });

            it("should treat the join keys as an optional argument", function() {
                function mul() { return 21 * 2; }
                mul = cr.spanWrap("span.mul", mul);
            });        

            it("should record the single join key", function() {
                function mul() { return 21 * 2; }
                mul = cr.spanWrap("span.mul", { username : "test" }, mul);

                mul();
                mul();
                cr.flush(true);
                assert.equal(stub.requests.length, 1);

                var req = _.first(stub.requests);
                assert.lengthOf(req.log_records, 0);
                assert.lengthOf(req.span_records, 2);
                _.each(req.span_records, function (record) {
                    assert.equal(record.span_name, "span.mul");
                    assert.equal(record.join_ids.length, 1);
                    assert.equal(record.join_ids[0].TraceKey, "username");
                    assert.equal(record.join_ids[0].Value, "test");
                });
            });

            it("should record the correct join keys", function() {
                function add(a, b) { return a + b; }
                add = cr.spanWrap("span.add", {
                    username : "alpha",
                    user_id  : "9876",
                }, add);

                add(4, 2);
                cr.flush(true);
                assert.equal(stub.requests.length, 1);

                var req = _.first(stub.requests);
                assert.lengthOf(req.log_records, 0);
                assert.lengthOf(req.span_records, 1);

                var record = _.first(req.span_records);
                assert.equal(record.span_name, "span.add");

                var joinIds = {};
                _.each(record.join_ids, function(joinId) {
                    joinIds[joinId.TraceKey] = joinId.Value;
                });

                assert.equal(_.size(joinIds), 2);
                assert.equal(joinIds["username"], "alpha");
                assert.equal(joinIds["user_id"], "9876");
            });

            it("should handle thrown exceptions correctly");

            it("should inherit global join ids correctly");

        });

        describe("spanSection", function() {
            it("should invoke the code section correctly");
            it("should handle thrown exceptions correctly");
        });
    });

    describe("Options", function() {

        describe("enable", function() {
            before(enableTestStub);
            after(function() {
                disableTestStub();
                cr.options({ enable : true });
            });
            beforeEach(resetTestStubData);

            it("should immediately be reflected in the status", function() {
                cr.options({ enable : true });
                assert.equal(cr.status().enabled, true);

                cr.options({ enable : true });
                assert.equal(cr.status().enabled, true);
                
                cr.options({ enable : false });
                assert.equal(cr.status().enabled, false);
                
                cr.options({ enable : false });
                assert.equal(cr.status().enabled, false);
                
                cr.options({ enable : true });
                assert.equal(cr.status().enabled, true);            
            });

            it("should not report log records when disabled", function() {
                cr.options({ enable : true });
                assert.equal(cr.status().enabled, true);
                cr.log("Test log message");
                cr.flush(true);
                assert.equal(stub.requests.length, 1);
                assert.lengthOf(stub.requests[0].log_records, 1);

                cr.options({ enable : false });
                assert.equal(cr.status().enabled, false);
                cr.log("Test log message");
                cr.log("Hello World!");
                cr.flush(true);
                assert.equal(stub.requests.length, 1);

                cr.options({ enable : true });
                assert.equal(cr.status().enabled, true);
                cr.log("Test log message");
                cr.flush(true);
                assert.equal(stub.requests.length, 2);
                assert.lengthOf(stub.requests[1].log_records, 1);
            });


            it("should not report span records when disabled", function() {
                cr.options({ enable : true });
                assert.equal(cr.status().enabled, true);
                var span = cr.span("test_span");
                span.end();
                cr.flush(true);
                assert.equal(stub.requests.length, 1);
                assert.lengthOf(stub.requests[0].span_records, 1);

                cr.options({ enable : false });
                assert.equal(cr.status().enabled, false);
                var span = cr.span("test_span");
                span.end();
                cr.flush(true);
                assert.equal(stub.requests.length, 1);

                cr.options({ enable : true });
                assert.equal(cr.status().enabled, true);
                var span = cr.span("test_span");
                span.end();
                cr.flush(true);
                assert.equal(stub.requests.length, 2);
                assert.lengthOf(stub.requests[1].span_records, 1);
            });

            it("should provide the same span handle interface whether enabled or disabled", function() {

                // Exposed interfaces when enabled and disabled
                var enabledInterface = {};
                var disabledInterface = {};

                // Collect enabled interface
                cr.options({ enable : true });
                var espan = cr.span("enabled_span");
                for (var key in espan) {
                    if (typeof espan[key] === "function") {
                        enabledInterface[key] = true;
                    }
                }
                espan.end();

                // Collect disabled interface
                cr.options({ enable : false });
                var dspan = cr.span("disabled_span");
                for (var key in dspan) {
                    if (typeof dspan[key] === "function") {
                        disabledInterface[key] = true;
                    }                
                }
                dspan.end();

                for (var key in enabledInterface) {
                    assert.typeOf(dspan[key], "function", "Disabled span missing method: " + key);
                }
                for (var key in disabledInterface) {
                    assert.typeOf(espan[key], "function", "Enabled span missing method: " + key);
                }
            });

            it("should provide a noop handle for spans when disabled", function() {

                cr.options({ enable : true });
                assert.equal(cr.status().enabled, true);

                var outer = cr.span("outer");
                    var inner = outer.span("inner");
                    inner.log("data", 123, 456.0);
                    inner.end();
                outer.end();
                
                cr.flush(true);
                assert.equal(stub.requests.length, 1);
                assert.lengthOf(stub.requests[0].log_records, 1);
                assert.lengthOf(stub.requests[0].span_records, 2);

                // Repeat the above with cruntime disabled.  The report numbers
                // should be unaffected.
                cr.options({ enable : false });
                assert.equal(cr.status().enabled, false);

                var outer = cr.span("outer");
                    var inner = outer.span("inner");
                    inner.log("data", 123, 456.0);
                    inner.end();
                outer.end();
                
                cr.flush(true);
                assert.equal(stub.requests.length, 1);
                assert.lengthOf(stub.requests[0].log_records, 1);
                assert.lengthOf(stub.requests[0].span_records, 2);

                // And does it re-enable?
                cr.options({ enable : true });
                assert.equal(cr.status().enabled, true);

                var outer = cr.span("outer");
                    var inner = outer.span("inner");
                    inner.log("data", 123, 456.0);
                    inner.end();
                outer.end();
                
                cr.flush(true);
                assert.equal(stub.requests.length, 2);
                assert.lengthOf(stub.requests[1].log_records, 1);
                assert.lengthOf(stub.requests[1].span_records, 2);            
            });
        });

        describe("max_*_records", function() {
            before(enableTestStub);
            after(function() {
                disableTestStub();
                cr.options({ 
                    max_log_records  : null,
                    max_span_records : null,
                });
            });
            beforeEach(resetTestStubData);

            it("should immediately set the options", function() {
                var base = cr.stats();

                assert.typeOf(base.max_log_records, "number");
                assert.typeOf(base.max_span_records, "number");

                cr.options({ 
                    max_log_records  : 32, 
                    max_span_records : 64,
                });
                var stats = cr.stats();
                assert.equal(stats.max_log_records, 32);
                assert.equal(stats.max_span_records, 64);

                cr.options({
                    max_log_records  : null, 
                    max_span_records : null,
                });
                var stats = cr.stats();
                assert.equal(stats.max_log_records,  base.max_log_records);
                assert.equal(stats.max_span_records, base.max_span_records);                
            });

            it("should enforce 1 as the minimum buffer sizes", function() {
                cr.options({ 
                    max_log_records  : -1, 
                    max_span_records : -1,
                });
                var stats = cr.stats();
                assert.equal(stats.max_log_records, 1);
                assert.equal(stats.max_span_records, 1);
            });

            it("should not record log records beyond the max", function() {
                var cases = [
                    [  4,   2,   2 ],
                    [  4,   4,   4 ],
                    [  4, 256,   4 ],
                    [ 16,   4,   4 ],
                    [ 16, 256,  16 ],
                    [ 17, 256,  17 ],
                    [  0,  16,   1 ],   // <-- the min buffer size is 1
                    [ -1,  16,   1 ],   // <-- the min buffer size is 1
                    [ Infinity, 256, 256 ], 
                ];
                _.each(cases, function (test) {
                    var max = test[0];
                    var logs = test[1];
                    var expected = test[2];

                    cr.options({ max_log_records : max });
                    for (var i = 0; i <  logs;i++) {
                        cr.log("Number", i);
                    }
                    cr.flush(true);
                    assert.lengthOf(_.last(stub.requests).log_records, expected);
                });
            });

            it("should not record span records beyond the max", function() {

                var cases = [
                    [  4,   2,   2 ],
                    [  4,   4,   4 ],
                    [  4, 256,   4 ],
                    [ 16,   4,   4 ],
                    [ 16, 256,  16 ],
                    [ 17, 256,  17 ],
                    [  0,  16,   1 ],   // <-- the min buffer size is 1
                    [ -1,  16,   1 ],   // <-- the min buffer size is 1
                    [ Infinity, 256, 256 ], 
                ];
                _.each(cases, function (test) {
                    var max = test[0];
                    var logs = test[1];
                    var expected = test[2];

                    cr.options({ max_span_records : max });
                    for (var i = 0; i <  logs;i++) {
                        var span = cr.span("span_" + i);
                        span.end();
                    }
                    cr.flush(true);
                    assert.lengthOf(_.last(stub.requests).span_records, expected);
                });

            });
        });
    });

    describe("Memory Usage", function() {

        before(enableTestStub);
        after(disableTestStub);
        beforeEach(function() {
            cr.options({ reset_object_pools : true });
            resetTestStubData();
        });

        it("should reuse log records", function() {
            // Clean start?
            var stats = cr.stats();
            assert.equal(stats.log_records_allocated, 0);
            assert.equal(stats.log_records_active, 0);

            for (var i = 0; i < 10; i++) {
                cr.info("A number is:", i);
            }

            // Before flushing...
            stats = cr.stats();
            assert.ok(stats.log_records_allocated >= 10);
            assert.equal(stats.log_records_released, 0);
            assert.equal(stats.log_records_active, 10);

            cr.flush(true);

            // After flushing..
            stats = cr.stats();
            assert.ok(stats.log_records_allocated >= 10);
            assert.equal(stats.log_records_released, 10);
            assert.equal(stats.log_records_active, 0);

            for (var i = 10; i < 20; i++) {
                cr.info("Another number is:", i);
            }

            // Before flushing...
            stats = cr.stats();
            assert.ok(stats.log_records_allocated >= 10);
            assert.equal(stats.log_records_released, 10);
            assert.equal(stats.log_records_active, 10);

            cr.flush(true);

            // After flushing..
            stats = cr.stats();
            assert.ok(stats.log_records_allocated >= 10);
            assert.equal(stats.log_records_released, 20);
            assert.equal(stats.log_records_active, 0);        
        });

        it("should work correctly with lots of records", function() {
            // Clean start?
            var stats = cr.stats();
            assert.equal(stats.log_records_allocated, 0);
            assert.equal(stats.log_records_active, 0);

            for (var j = 0; j < 16; j++) {
                for (var i = 0; i < 512; i++) {
                    cr.info("LOG#", i);
                }
                var stats = cr.stats();
                assert.equal(stats.log_records_active, 512);   
                cr.flush(true);
            }

            assert.equal(stub.requests.length, 16);

            stats = cr.stats();
            assert.equal(stats.log_records_acquired, stats.log_records_released);   
            assert.equal(stats.log_records_active, 0);   
        });

        it("should balance trace join id acquire/release calls", function() {
            // Clean start?
            var stats = cr.stats();
            assert.equal(stats.join_ids_allocated, 0);
            assert.equal(stats.join_ids_active, 0);

            var s = cr.span("test");
            s.end();
            cr.flush(true);

            stats = cr.stats();
            assert.equal(stats.join_ids_allocated, 0);
            assert.equal(stats.join_ids_active, 0);

            s = cr.span("test", { key : "value" });
            
            stats = cr.stats();
            assert.equal(stats.join_ids_allocated, 1);
            assert.equal(stats.join_ids_active, 1);   
            
            s.end();
            cr.flush(true);

            stats = cr.stats();
            assert.equal(stats.join_ids_allocated, 1);
            assert.equal(stats.join_ids_active, 0);  
        });

        it("should balance trace join id acquire/release in nested spans", function() {
            // Clean start?
            var stats = cr.stats();
            assert.equal(stats.join_ids_allocated, 0);
            assert.equal(stats.join_ids_active, 0);

            var s = cr.span("span1", { key1 : "value1", key2 : "value2" });

                stats = cr.stats();
                assert.equal(stats.join_ids_allocated, 2);
                assert.equal(stats.join_ids_active, 2);

                var t = s.span("span2", { key3 : "value3" });

                // This part of the test exposes a bit of an implementation detail as
                // the join_ids are expected to be copied, not shared.  C'est la vie.
                stats = cr.stats();
                assert.equal(stats.join_ids_allocated, 5);
                assert.equal(stats.join_ids_active, 5);

                t.end();
                // The Join IDs are still active until the flush
                assert.equal(cr.stats().join_ids_active, 5);

            s.end();
            assert.equal(cr.stats().join_ids_active, 5);  
            cr.flush(true);

            assert.equal(cr.stats().join_ids_active, 0);  
        });    
    });


    describe("Regression Tests", function() {
        it("should not globally import color modifiers", function() {
            var s = "a string";
            assert.typeOf(s["red"], "undefined");
            assert.typeOf(s["green"], "undefined");
            assert.typeOf(s["yellow"], "undefined");
        });
    });
};