//===========================================================================//
// Memory Management
//===========================================================================//

var kSpanHandlesPoolInitialSize = 32;

var ObjectPool = require("./object_pool.js");

var pool = {
    spanHandles : new ObjectPool({
        constructor  : SpanHandle,
        initial_size : kSpanHandlesPoolInitialSize,
        object_reset : function(obj, args) { 
            this._record = null;
            this._state = null;
        },
    }),
};

//===========================================================================//
// SpanHandle
//===========================================================================//
//
// A handle exposing an active span to the client.  
//
// Terminology: the "span record" is the data associated with a completed 
// span and the "span handle" is the interface for interacting with an active
// span.
//
// Dev note: this interface should mirror the cruntime API (where common sense
// applies).
//
function SpanHandle(state, record) {
    // Don't call release() on _record as this is non-owning reference.
    this._record = record; 
    this._state = state;
}

SpanHandle.prototype.guid = function() {
    if (!this._record) {
        logUserError(this._state, "Invalid span handle", arguments);
        return 0;
    } else {
        return this._record.span_guid;
    }
};

// Ends the span.  This should be called exactly once.
SpanHandle.prototype.end = function() {
    if (!this._record) {
        logUserError(this._state, "Invalid span handle", arguments);
        return;
    }
    console.assert(this._record.span_guid !== null, "Span requires a GUID");
    console.assert(this._record.youngest_micros === null, "span end() has already been called");

    if (this._record.youngest_micros === null) {
        this._record.youngest_micros = this._state.nowMicros();
        this._state.pushSpanRecord(this._record);
        
        this._record = null;
        pool.spanHandles.release(this);
    }
};

// Wrap a function and end the span as soon as that function is invoked.  
// Useful for asynchronous done/complete/next callbacks.
//
// Example:
//
// var span = cr.span("read_my_file")
// fs.readFile("my_file.txt", span.endWrap(function (err, buf) {
//     ...
// }));
//
SpanHandle.prototype.endWrap = function(f) {
    var self = this;
    return function() {
        self.end();
        var r;
        try {
            r = f.apply(this, arguments);
        } catch (e) {
            self.exception(e);
            throw e;
        }
        return r;
    };
};

// Merge additional join ids in to the active span. 
SpanHandle.prototype.joinIds = function (joinIds) {
    if (!this._record) {
        logUserError(this._state, "Invalid span handle", arguments);
    } else {
        this._state.mergeJoinIdMapIntoSpanRecord(this._record, joinIds);
    }
};

//===========================================================================//
// console-style logging
//===========================================================================//

SpanHandle.prototype.log = function() {
    if (!this._record) {
        logUserError(this._state, "Invalid span handle", arguments);
    } else {
        this._state.logArgumentsInfo(arguments, this._record.span_guid);
    }
};

SpanHandle.prototype.info = SpanHandle.prototype.log;

SpanHandle.prototype.warn = function() {
    if (!this._record) {
        logUserError(this._state, "Invalid span handle", arguments);
    } else {
        this._state.logArgumentsWarn(arguments, this._record.span_guid);
    }
};

SpanHandle.prototype.error = function() {
    if (!this._record) {
        logUserError(this._state, "Invalid span handle", arguments);
    } else {
        this._state.logArgumentsError(arguments, this._record.span_guid);
    }
};

SpanHandle.prototype.fatal = function() {
    // The implementation of fatal intentionally differs from info/warn/error
    // on a bad record: take the fatal seriously and pass it on to the state
    // object.
    var guid;
    if (this._record) {
        guid = this._record.span_guid;
        logUserError(this._state, "Invalid span handle", arguments);
    }
    this._state.logArgumentsFatal(arguments, guid);
};

//===========================================================================//
// glog-style logging
//===========================================================================//

SpanHandle.prototype.logf = function() {
    if (!this._record) {
        logUserError(this._state, "Invalid span handle", arguments);
    } else {
        this._state.logFormattedInfo(arguments, this._record.span_guid);
    }
};

SpanHandle.prototype.infof = SpanHandle.prototype.logf;

SpanHandle.prototype.warnf = function() {
    if (!this._record) {
        logUserError(this._state, "Invalid span handle", arguments);
    } else {
        this._state.logFormattedWarn(arguments, this._record.span_guid);
    }
};

SpanHandle.prototype.errorf = function() {
    if (!this._record) {
        logUserError(this._state, "Invalid span handle", arguments);
    } else {
        this._state.logFormattedError(arguments, this._record.span_guid);
    }
};

SpanHandle.prototype.fatalf = function() {
    // The implementation of fatal intentionally differs from info/warn/error
    // on a bad record: take the fatal seriously and pass it on to the state
    // object.
    var guid;
    if (this._record) {
        guid = this._record.span_guid;
        logUserError(this._state, "Invalid span handle", arguments);
    }
    this._state.logFormattedFatal(arguments, guid);
};

SpanHandle.prototype.exception = function(e) {
    var guid;
    if (this._record) {
        guid = this._record.span_guid;
        logUserError(this._state, "Invalid span handle", arguments);
    }    
    this._state.logException(arguments, guid);
};

//===========================================================================//
// Events
//===========================================================================//

SpanHandle.prototype.event = function(name, payload) {
    if (!this._record) {
        logUserError(this._state, "Invalid span handle", arguments);
    } else {
        this._state.logEvent(name, payload, this._record.span_guid);
    }
};

//===========================================================================//
// Spans
//===========================================================================//

SpanHandle.prototype.span = function (suffix, joinIdKeyValues) {
    var inner;
    if (!this._record) {
        logUserError(this._state, "Invalid span handle", arguments);
        inner = this._state.rawSpanBegin(suffix, joinIdKeyValues);
    } else {
        var joinIds = mergeTraceIds(this._record.join_ids, joinIdKeyValues);
        inner = this._state.rawSpanBegin(this._record.span_name + "." + suffix, joinIds);
    }
    return this._state.createSpanHandle(inner);
};

SpanHandle.prototype.spanSection = function (suffix, joinIdKeyValues, f) {
    if (arguments.length === 2) {
        f = joinIdKeyValues;
        joinIdKeyValues = {};
    }
    var joinIds = mergeTraceIds(this._record.join_ids, joinIdKeyValues);
    return this._state.spanSection(this._record.span_name + "." + suffix, joinIds, f);
};

//===========================================================================//
// Helpers
//===========================================================================//

// For user-caused internal errors.
function logUserError (state, text, args) {
    state.rawLogRecord({
        level       : "E",
        filename    : "<span_handle>",
        message     : text,
        stack_frames: state.stackTrace(),
        payload     : {
            arguments : Array.prototype.slice.call(args),
        },
    });
}

// Merges the parent array representation with a map and returns a map.
// parentArray should an array; toMerge should be a map or may be undefined.
//
// TODO: fix this data structure ping-pong!
 function mergeTraceIds (parentArray, toMerge) {
    var map = {};
    for (var i = 0; i < parentArray.length; i++) {
        var pair = parentArray[i];
        map[pair.TraceKey] = pair.Value;
    }
    if (toMerge) {
        for (var key in toMerge) {
            map[key] = toMerge[key];
        }
    }
    return map;
}


//===========================================================================//
// NoOpHandle
//===========================================================================//
// Returned when the cruntime is disabled

function NoOpHandle() {
    // MUST have no state as the object is effectively used as a 
    // singleton.
}

// Create true no-op functions as a default, then override the methods
// that need to do something beyond trace functionality.
for (var key in SpanHandle.prototype) {
    NoOpHandle.prototype[key] = function() {};
}

NoOpHandle.prototype.endWrap = function(f) {
    return f;
};

NoOpHandle.prototype.span = function (suffix, joinIdKeyValues, f) {
    return this;
};

NoOpHandle.prototype.spanSection = function (suffix, joinIdKeyValues, f) {
    if (arguments.length === 2) {
        f = joinIdKeyValues;
    }
    return f();
};

//===========================================================================//
// Exports
//===========================================================================//

var lib = {};

lib.acquire = function(state, record) {
    var obj = pool.spanHandles.acquire();
    SpanHandle.call(obj, state, record);
    return obj;
};

module.exports = lib;
