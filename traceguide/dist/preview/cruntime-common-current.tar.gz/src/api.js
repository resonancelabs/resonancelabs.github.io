// Defines the common, client-facing API for cruntime. The platform-specific API 
// may be a slight variation of this depending on platform capabilities.
//
// The code herein is intended to a slim syntactic layer over the implementation
// provided by the State object.

var imp = null;
var lib = {};

//===========================================================================//
// Initialization & Configuration
//===========================================================================//

lib.initialize = function() { return imp.initialize.apply(imp, arguments); };

// Sets the options for the runtime library itself.
lib.options    = function() { return imp.options.apply(imp, arguments); };

// Sets attributes that describe the runtime.
lib.attributes = function() { return imp.runtimeAttributes.apply(imp, arguments); };

// Return the runtime's GUID
lib.guid = function() { return imp.runtimeGUID(); };

// Returns a status object describing the current state of the runtime.
lib.status = function() { return imp.getStatus(); };

//===========================================================================//
// Logging
//===========================================================================//

// -- console object compatible API --- 
//
// Takes variable numbers of arguments, logging them as a space-separated 
// list.
//

lib.log     = function() { return imp.logArgumentsInfo(arguments); };
lib.info    = function() { return imp.logArgumentsInfo(arguments); };
lib.warn    = function() { return imp.logArgumentsWarn(arguments); };
lib.error   = function() { return imp.logArgumentsError(arguments); };
lib.fatal   = function() { return imp.logArgumentsFatal(arguments); };

// -- glog / sprintf compatible API --- //
//
// Takes sprintf-like format string as a first argument followed by a series
// of data objects.
//

lib.logf    = function() { return imp.logFormattedInfo(arguments); };
lib.infof   = function() { return imp.logFormattedInfo(arguments); };
lib.warnf   = function() { return imp.logFormattedWarn(arguments); };
lib.errorf  = function() { return imp.logFormattedError(arguments); };
lib.fatalf  = function() { return imp.logFormattedFatal(arguments); };

// -- miscellaneous -- //

// Logs exception objects in a consistent manner
lib.exception = function(e) { return imp.logException(e); };

//===========================================================================//
// Events
//===========================================================================//

lib.event     = function(name, payload) { return imp.logEvent.call(imp, name, payload); };
lib.eventWrap = function(name, f)       { return imp.eventWrap.apply(imp, arguments);  };

//===========================================================================//
// Spans
//===========================================================================//

lib.span        = function() { return imp.span.apply(imp, arguments); };
lib.spanWrap    = function() { return imp.spanWrap.apply(imp, arguments); };
lib.spanSection = function() { return imp.spanSection.apply(imp, arguments); };

lib.spanManual  = function() { return imp.spanManual.apply(imp, arguments); };

//===========================================================================//
// Counters & Gauges 
//===========================================================================//

// TBD

//===========================================================================//
// Buffer Control
//===========================================================================//

lib.pause   = function()            { throw new Error("NOT_YET_IMPLEMENTED"); };
lib.resume  = function()            { throw new Error("NOT_YET_IMPLEMENTED"); };
lib.flush   = function(synchronous) { return imp.flushBuffer(synchronous); };
lib.discard = function()            { imp.discardBuffers(); };

//===========================================================================//
// Reporting
//===========================================================================//

lib.stats = function() { return imp.reportBufferStats(); };

//===========================================================================//
// Exports
//===========================================================================//

module.exports = function(implObject) {
    imp = implObject;
    imp.api = lib;

    // TODO: Remove this field. The implementation object should *never* need
    // to be accessed directly. It's here for development to allow inspection
    // of the values during debugging.
    lib.__imp = imp;
    
    return lib;
};
