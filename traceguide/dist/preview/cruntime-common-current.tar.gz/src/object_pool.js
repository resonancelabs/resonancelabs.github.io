
//===========================================================================//
// Memory Management
//===========================================================================//

function ObjectPool(opts) {
    var reserveCount = opts.reserve || 32;

    this._ctor = opts.constructor;
    this._reset = opts.object_reset;
    this._pop_front = opts.pop_front || false;

    this.allocationCount = 0;
    this.acquireCount = 0;
    this.releaseCount = 0;
    this.freeList = new Array(reserveCount);

    for (var i = 0; i < reserveCount; i++) {
        this.freeList[i] = this.newObject();
    }
}

ObjectPool.prototype.newObject = function() {
    this.allocationCount++;
    return new (this._ctor)();
};

ObjectPool.prototype.acquire = function(args) {
    this.acquireCount ++;
    var obj;
    if (this.freeList.length) {
        obj = this.freeList.pop();
    } else {
        obj = this.newObject();
    }
    this._reset(obj, args);
    return obj;
};

ObjectPool.prototype.release = function(obj) {
    if (obj === undefined || obj === null) {
        console.assert(false, "Attempt to release an invalid object.");
        return;
    }

    console.assert(this.acquireCount > this.releaseCount, "Imbalance in acquire/release counts!");
    this.releaseCount ++;
    this._reset(obj);
    this.freeList.push(obj);
};

// Effectively reinitializes the pool by reseting counters and reseting
// the free list.  Existing objects, of course, still exist and will
// be GC'ed normally.
ObjectPool.prototype.reset = function() {
    this.allocationCount = 0;
    this.acquireCount = 0;
    this.releaseCount = 0;
    this.freeList = [];
};

module.exports = ObjectPool;
