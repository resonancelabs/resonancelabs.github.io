//===========================================================================//
// Dependencies & Consts
//===========================================================================//

var ObjectPool  = require("./object_pool.js"),
    span_handle = require("./span_handle.js"),
    inspectify  = require("node/packages/rl-inspectable-object");

var kRefreshIntervalMs          = 2500;     // TODO: this should probably be configurable

var kLogRecordsPoolInitialSize  = 128;
var kSpanRecordsPoolInitialSize = 32;
var kTraceJoinIdPoolInitialSize = 64;

var kMaxLogRecordsDefault       = 1024;
var kMaxSpanRecordsDefault      = 1024;

//===========================================================================//
// Globals
//===========================================================================//
// Use globals mostly for coding convenience.  No runtime is (currently) 
// expected to have multiple State objects; this may change in the future.

// State object
var singleton       = null;

// Thrift
var crouton_thrift  = null;
var Thrift          = null;

// Memory management
var pool = {
    logRecords      : null,
    spanRecords     : null,
    traceJoinIds    : null,
};

// Platform abstraction layer
var platform        = null;

// Saved global state in case we're asked to override it
var originalConsole = console;

function initializeGlobals(state, crouton_thrift_, Thrift_, platform_) {
    //
    // Singleton...
    //
    // This is mostly for coding convenience. In theory, we may want to 
    // to have less global state when proxying different services so that
    // the runtime attributes, buffering strategies, etc. can vary between
    // those data sources.
    //
    if (singleton !== null) {
        throw new Error("State is intended to be a singleton.");
    }
    singleton = state;

    //
    // Platform...
    //
    platform = platform_;

    //
    // Thrift...
    //
    crouton_thrift = crouton_thrift_;
    Thrift         = Thrift_;

    //
    // Memory Pools...
    //
    // These rely on the thrift implementation to clear out all the fields.
    // Seems a bit fragile, but manually listing out the fields and clearing
    // them is also fragile if new fields are added.
    pool.logRecords = new ObjectPool({
        constructor  : crouton_thrift.LogRecord, 
        initial_size : kLogRecordsPoolInitialSize, 
        object_reset : function(obj, args) { crouton_thrift.LogRecord.call(obj, args); },
    });
    pool.spanRecords = new ObjectPool({
        constructor  : crouton_thrift.SpanRecord, 
        initial_size : kSpanRecordsPoolInitialSize, 
        object_reset : function(obj, args) { crouton_thrift.SpanRecord.call(obj, args); },
    });    
    pool.traceJoinIds = new ObjectPool({
        constructor  : crouton_thrift.TraceJoinId,
        initial_size : kTraceJoinIdPoolInitialSize,
        object_reset : function(obj, args) { crouton_thrift.TraceJoinId.call(obj, args); },
    });
}

function releaseSpanRecord (span) {
    console.assert(span.span_guid !== null, "Invalid span being released.");
    if (span.join_ids) {
        for (var j = 0; j < span.join_ids.length; j++) {
            pool.traceJoinIds.release(span.join_ids[j]);
        }
    }
    pool.spanRecords.release(span);
}

// Balance the acquire()'ed objects with release() calls.
function releaseArrays (logs, spans) {
    // Release log record objects
    for (var i = 0; i < logs.length; i++) {
        pool.logRecords.release(logs[i]);
    }
    // Release span record object and any contained join ids
    for (i = 0; i < spans.length; i++) {
        releaseSpanRecord(spans[i]);
    }
}

//===========================================================================//
// State
//===========================================================================//

function State(thriftTypes, thriftLibrary, platform, groupName, postInitialize) {

    initializeGlobals(this, thriftTypes, thriftLibrary, platform);

    // Handle to the client-api.  Set externally by the API creation code.
    this.api = null;

    // Configuration
    this.serviceHost = "localhost";
    this.servicePort = platform.isNode ? 10000 : 9999;
    this.bufferMaxSpanRecords = kMaxSpanRecordsDefault;
    this.bufferMaxLogRecords  = kMaxLogRecordsDefault;

    // Thrift runtime object and client object
    this.runtime = new crouton_thrift.Runtime();
    this.runtime.guid = platform.generateGUID();
    this.runtime.group_name = groupName;
    this.runtime.start_micros = platform.nowMicros();

    // Thrift client object - initialized at the start of the refresh loop
    this.client     = null;
    this.auth       = new crouton_thrift.Auth();

    // Status
    this.refreshLoopActive = false;
    this.flushActive = false;

    // Callback hooks for the platform-specific aspects
    this.hooks = {
        postInitialize : postInitialize || function() {},
    };
    this.initialized = false;

    // Runtime info
    this.enabled    = true; // If false, turn the runtime into as close to a noop as possible
    this.joinIds    = {};   // Global join ids that will be inherited by 

    // Buffers
    this.spans      = [];
    this.logs       = [];

    // Reusable objects / object pools to reduce gc thrashing
    this.reusable = {
        proxyReportRequest  : new crouton_thrift.ProxyReportRequest(),
        status              : {},
    };

    // Adapters on the client RPCs (due to asymmetry in the node / browser
    // thrift calling conventions).
    this.invokeProxyReport = null;

    // Make the State object into a Facade that hides the platform differences
    //
    // TODO: eventually hide the need for an explicit isNode bool!
    //
    this.isNode             = platform.isNode;
    this.nowMicros          = function() { return platform.nowMicros(); };
    this.generateGUID       = function() { return platform.generateGUID(); };
    this.logger             = platform.logger;
    this.stackTrace         = function() { return platform.stackTrace(); };
    this.processAbort       = function() { return platform.abort(); };
    this.defaultLogFilename = function() { return platform.defaultLogFilename(); };
}

State.prototype.initialize = function(opts) {   
    // Treat redundant initialize calls as options() calls to merge any
    // and all options.
    this.options(opts);

    // Only start the reporting loop if there's an access token set and
    // if not explicitly paused.
    //
    // TODO: this is a little odd as it's outside the this.initialized check
    // as multiple initialize() calls *are* currently allowed and the behavior
    // is to start on the first on that provides a valid access token. This
    // is not fantastically clear behavior.
    var paused = opts ? opts.paused : false;
    if (this.auth.access_token && !paused) {
        this.startFlushBufferLoop();
    }

    if (this.initialized) {
        return;
    }
    this.initialized = true;

    // Only call this once
    this.hooks.postInitialize(this.api);
};

// Sets options on the runtime.
State.prototype.options = function (opts) {
    var self = this;
    if (!opts) {
        return;
    }
    if (typeof opts !== "object") {
        this.logArgumentsError(["options called with a non-object argument"]);
        return;
    }

    //
    // enable {boolean}
    //
    if (typeof opts.enable !== "undefined") {
        this.setEnabled(opts.enable);
    }

    //
    // access_token {string}
    //
    if (typeof opts.access_token === "string") {
        this.auth.access_token = opts.access_token;
    }

    //
    // service_host {string}
    //
    // Sets the host use for reporting.
    //
    if (typeof opts.service_host === "string") {
        this.serviceHost = opts.service_host;
    }

    //
    // service_port {int|string} 
    //
    // Sets the port use for reporting.
    // 
    if (opts.service_port) {
        var port = parseInt(opts.service_port);
        this.servicePort = port;
    }

    //
    // group_name {string}
    //
    // Sets the runtime's group_name.
    //
    if (typeof opts.group_name === "string") {
        this.runtime.group_name = opts.group_name;
    }

    //
    // join_ids {object} 
    //
    // A set of string-to-string key-value pairs to be set globally for the
    // runtime.  All created spans will inherit these join ids.
    //
    if (opts.join_ids !== undefined) {
        for (var key in opts.join_ids) {
            this.joinIds[key] = opts.join_ids[key];
        }
    }    

    //
    // max_log_records {int}
    //
    // Maximum number of log records to buffer. If the current buffer already
    // exceeds this size, the buffer size will not reset until the next
    // report.
    //
    // Setting to null will reset to the default value.
    //
    if (typeof opts.max_log_records === "number") {
        // Always buffer at least 1; this simplifies the runtime logic and the
        // client can always set "enable" to false.        
        this.bufferMaxLogRecords = Math.max(opts.max_log_records, 1);
    } else if (opts.max_log_records === null) {
        this.bufferMaxLogRecords = kMaxLogRecordsDefault;
    }

    //
    // max_span_records {int}
    //
    // Maximum number of log records to buffer. If the current buffer already
    // exceeds this size, the buffer size will not reset until the next
    // report.
    //
    // Setting to null will reset to the default value.
    //
    if (typeof opts.max_span_records === "number") {
        // Always buffer at least 1; this simplifies the runtime logic and the
        // client can always set "enable" to false.
        this.bufferMaxSpanRecords = Math.max(opts.max_span_records, 1);
    } else if (opts.max_span_records === null) {
        this.bufferMaxSpanRecords = kMaxSpanRecordsDefault;
    }

    //
    // override_console {bool}
    //
    // Override the global window.console / global.console object and pipe the
    // input through cruntime.  A value of `false` will reset the console object.
    if (opts.override_console !== undefined) {
        if (opts.override_console === true) {
            console.log   = function() { self.logArgumentsInfo.call(self, arguments); };
            console.warn  = function() { self.logArgumentsWarn.call(self, arguments); };
            console.error = function() { self.logArgumentsError.call(self, arguments); };
        } else {
            console.log   = originalConsole.log;
            console.warn  = originalConsole.warn;
            console.error = originalConsole.error;
        }
    }   

    //
    // -- internal use only --
    //
    // cruntime_platform {string}
    //
    // Platform of the cruntime itself (i.e. node or browser and a x.x.x semantic 
    // version string).
    if (typeof opts.cruntime_platform === "string") {
        this.replaceOrAddRuntimeKeyValue("cruntime_platform", opts.cruntime_platform);
    }

    //
    // -- internal use only --
    //
    // cruntime_platform {string}
    //
    // Semantic version of the cruntime itself (i.e. x.x.x style version string,
    // http://semver.org/).
    //    
    if (typeof opts.cruntime_version === "string") {
        this.replaceOrAddRuntimeKeyValue("cruntime_version", opts.cruntime_version);
    }


    //
    // -- internal use only --
    //
    // reset_object_pools {bool}
    //
    // Reset the object pools, for testing test the memory usage
    //
    if (opts.reset_object_pools) {
        this.resetObjectPools();
    }

    //
    // -- internal use only --
    //
    // override_abort {function()}
    //
    // Allow the platform abort() function to be overridden for testing.
    // Setting a value of `null` will revert back to the platform abort()
    // implementation.
    //
    if (opts.override_abort !== undefined) {
        if (typeof opts.override_abort === "function") {
            this.processAbort = opts.override_abort;
        } else {
            this.processAbort = function() { return platform.abort(); };
        }
    }

    //
    // -- internal use only --
    //
    // override_logger {object}
    //
    // Allow the platform console to be overridden for testing purposes.
    // The override is *not* a 1:1 mapping to the normal logger. Instead it
    // simplifies things down to a single function as this is for basic
    // testing.
    if (opts.override_logger !== undefined) {
        
        var f = opts.override_logger;
        if (typeof f == "function") {

            // Create a very simple logger proxy.
            var g = function(args) {
                return f(args.join(" "));
            };
            this.logger = {
                info  : g,
                warn  : g,
                error : g,
                fatal : g,
            };

        } else {

            this.logger = platform.logger;
        }        
    }

    //
    // -- internal use only --
    //
    // override_report_rpc {function(synchornous, request, callback(err, response))}
    //
    // Allow the reporting function to be overridden for testing. 
    if (opts.override_report_rpc !== undefined) {
        if (typeof opts.override_report_rpc === "function") {
            this.invokeProxyReport = opts.override_report_rpc;
        } else if (this.client) {
            // If there's a thrift client, connect back to the RPC
            this.invokeProxyReport = this.createAsyncRPCAdapter(this.client.ProxyReport, crouton_thrift.ProxyReportResponse);
        } else {
            // Otherwise, leave in the unconnected state
            this.invokeProxyReport = null;
        }
    }    
};

State.prototype.replaceOrAddRuntimeKeyValue = function(key, value) {
    var keyValue = new crouton_thrift.KeyValue();
    keyValue.Key = key;
    if (typeof value !== "string") {
        try {
            value = JSON.stringify(value);
        }
        catch (e) {
            value = toString.call(value);
        }
    }
    keyValue.Value = value;

    if (!this.runtime.attrs) {
        this.runtime.attrs = [];
    }
    for (var i = 0; i < this.runtime.attrs.length; i++) {
        var attr = this.runtime.attrs[i];
        if (attr.Key == key) {
            break;
        }
    }

    // JS reminder: setting to array[length] is the same as array.push(),
    // so this works for both the replace and insert cases.
    this.runtime.attrs[i] = keyValue;
};

State.prototype.runtimeAttributes = function (attrs) {
    if (typeof attrs !== "object") {
        // TODO: Some internal warning/error API is needed
        console.assert(false, "Unexpected attrs value");
        return;
    }
    for (var key in attrs) {
        this.replaceOrAddRuntimeKeyValue(key, attrs[key]);
    }
};

State.prototype.runtimeGUID = function() {
    return this.runtime.guid;
};

State.prototype.setEnabled = function(enable) {
    // Coerce into a bool
    enable = !(!enable || (enable === "false" ? true : false));  
    if (this.enabled === enable) {
        return;
    }

    this.enabled = enable;

    if (!enable) {
        // Respect the "turn this off!" command ASAP. Don't try to flush the
        // buffers -- discard 'em.
        this.discardBuffers();    
    }
};

State.prototype.getStatus = function() {
    var status = this.reusable.status;
    status.enabled = this.enabled;
    status.flushActvive = this.flushActive;
    return status;
};

//===========================================================================//
// Buffer / refresh loop
//===========================================================================//

// TODO: localStorage -- currently trying to force the RPC through on the
// beforeunload event doesn't seem to be working consistently.  Another option
// might be to stash the pending buffer into localStorage, and for the case
// where they are navigating to another page on the same site, they new page
// could then pick up that buffer on load and send it along.
//
State.prototype.flushBuffer = function(synchronous) {
    
    // Early out if there's nothing to do or waiting on an existing flush
    if (!this.enabled) {
        return;
    }
    if (this.flushActive) {
        return;
    }
    if (this.logs.length  === 0 && this.spans.length === 0) {
        return;
    }

    var self = this;

    // Allow a synchronous request as an option for the unload case where
    // we really want to cram that data across the wire before the user
    // leaves the page!
    synchronous = synchronous || false;

    var req = this.reusable.proxyReportRequest;
    req.runtime = this.runtime;
    req.timestamp_micros = platform.nowMicros();
    req.span_records = this.spans;
    req.log_records = this.logs;

    console.assert(req.runtime.guid, "Runtimes require a GUID");
    console.assert(req.runtime.group_name, "Runtimes require a group_name");

    // TL;DR: writing a custom thrift.js wouldn't be such a bad idea. 
    //
    // CAREFUL #1: the object passed to the callback as arg 1 is either the 
    // response object in the case of success, or the error which glancing at 
    // the JS library is either a string or a Thrift.TApplicationException (or
    // conceivably any kind of random exception that could be thrown during
    // processing).  In other words, it's probably best to check that res
    // against the expected instanceof type rather than checking for an 
    // error type.  Sigh, why didn't they just use the more standard
    // function(err, res) convention??
    //
    // CAREFUL #2: even if the callback is eventually a no-op, it still needs
    // to be passed into the call as the presence of the callback is how
    // thrift determines if it should be a synchronous or asychronous call.
    //
    // Both the above problems could be solved with minor modifications to
    // thrift.js but then means commiting to a forked version.
    //
        
    // Release the in-memory objects once the request goes through.
    console.assert(!this.flushActive, "Flush already active!");
    this.flushActive = true;

    var logs = this.logs;
    var spans = this.spans;
    try {
        this.invokeProxyReport(synchronous, req, function (err, res) {
            self.flushActive = false;
            if (err) {
                originalConsole.error("RPC error:", err);
            }
            releaseArrays(logs, spans);
        });
    } catch (e) {
        // TODO: should internally log this exception.
        if (this.flushActive) {
            releaseArrays(logs, spans);
            this.flushActive = false;
        }
    }

    // Clear the current buffers.  Note: this is not the same releasing the
    // objects themselves which is handled by releaseArrays().
    this.logs = [];
    this.spans = [];
};

// TODO: the connection initialization needs to be de-coupled from the looping
// logic as it is conceivable that a client might want to manual control the
// flush calls.
//
// TODO: Overlapping with the prior todo, this needs to check if the loop has
// already been started.
//
State.prototype.startFlushBufferLoop = function() {
    
    // Ignore redundant requests
    if (this.refreshLoopActive) {
        return;
    }

    console.assert(this.client === null, "Client already initialized");

    var self = this;

    // TODO: encapsulate all platform differences in a separate package
    // and get rid of these isNode checks.
    if (!this.isNode) {

        // Note this is implicitly using the JSON protocol -- not the binary protocol.
        // That's the default (and only supported JS protocol).
        var serviceUrl = "http://" + this.serviceHost + ":" + this.servicePort + "/";  
        var transport = new Thrift.Transport(serviceUrl);
        var protocol  = new Thrift.Protocol(transport);
        this.client   = new crouton_thrift.CroutonServiceClient(protocol);

    } else {

        var options = {
            transport : Thrift.TBufferedTransport,
            protocol  : Thrift.TBinaryProtocol,
            path      : "/",
            https     : false,
        };

        var connection = Thrift.createHttpConnection(this.serviceHost, this.servicePort, options);
        this.client = Thrift.createHttpClient(crouton_thrift.CroutonServiceClient, connection);

        connection.on("error", function(err) {
            originalConsole.error("cruntime thrift error:", err);
        });
    }

    // The reporting function might be non-null already if it has been 
    // manually overridden, e.g. for unit testing.  Don't clobber that 
    // value.
    if (!this.invokeProxyReport) {
        this.invokeProxyReport = this.createAsyncRPCAdapter(this.client.ProxyReport, crouton_thrift.ProxyReportResponse);
    } 
    
    this.refreshLoopActive = true;
    (function loop() {
        self.flushBuffer();
        setTimeout(loop, kRefreshIntervalMs);
    })();
};

// RPC adapters since thrift has different calling conventions for the
// browser and node.js. (This is *almost* sufficiently annoying to consider
// forking thrift and fixing this particular piece of poor design.)
//
// This normalizes on a function (err, res) { ... } style callback.
// 
// TODO: it might be nice to hide this in the platform-dependent code, not
// here.  But it is less indirection to just do it here.
//
State.prototype.createAsyncRPCAdapter = function(rpc, respType) {
    var self = this;

    var callbackAdapter;
    if (!this.isNode) {
        
        // Browser case.
        return function(synchronous, req, callback) {
            console.assert(self.auth && self.auth.access_token, "Expected access_token");

            if (!synchronous) {
                rpc.call(self.client, self.auth, req, function(res) {
                    // The thrift browser-side convention here is frustrating. Valid
                    // responses and errors are overloaded into the same variable and
                    // need to be differentiated by a type-check.
                    if (!(res instanceof respType)) {
                        callback(res, null);
                    } else {
                        callback(null, res);
                    }
                });
            } else {
                var res = this.client.ProxyReport(null, req);
                if (!(res instanceof crouton_thrift.ProxyReportResponse)) {
                    return callback(res, null);
                } else {
                    return callback(null, res);
                }   
            }
        };

    } else {

        // Node.js case.
        return function(synchronous, req, callback) { 
            console.assert(self.auth && self.auth.access_token, "Expected access_token");
            console.assert(!synchronous, "Node.js RPC only supports asynchronous calls!");
            rpc.call(self.client, self.auth, req, callback);
        };
    }
};

// Discard any unflushed data currently in the buffers
State.prototype.discardBuffers = function() {
    releaseArrays(this.logs, this.spans);
    this.logs = [];
    this.spans = [];
};

// Intended for internal use only for debugging.
State.prototype.resetObjectPools = function() {
    pool.logRecords.reset();
    pool.spanRecords.reset();
    pool.traceJoinIds.reset();
};

//===========================================================================//
// Logs
//===========================================================================//

State.prototype.rawLogRecord = function (fields) {
    console.assert(this.runtime, "Runtime has not been initialized properly");
    if (!this.enabled) {
        return;
    }

    // All fields except payload can be passed in without transformation.
    // The payload needs to be JSON stringified first (since it contains
    // unstructured data as far as far as Thrift is concerned).
    if (fields.payload !== null && fields.payload !== undefined) {
        fields.payload_json = JSON.stringify(inspectify(fields.payload));
        fields.payload = null;
    }

    var record = pool.logRecords.acquire(fields);
    record.runtime_guid = this.runtime.guid;
    record.timestamp_micros = platform.nowMicros();

    if (this.logs.length >= this.bufferMaxLogRecords) {
        // Treat this like a random sampling and replace a record at random.
        // This is not truly random in mathematical sense for a number of reasons,
        // but the assumption this is provides more useful information than 
        // dropping all records once the max is hit.
        var index = Math.floor(this.logs.length * Math.random());
        pool.logRecords.release(this.logs[index]);
        this.logs[index] = record;
    } else {
        this.logs.push(record);
    }
};

State.prototype.logArgumentsWithSpanGUID = function(spanGUID, level, args) {
    if (!this.enabled) {
        return;
    }
    this.rawLogRecord({
        level       : level,
        filename    : this.defaultLogFilename(),
        message     : args.join(" "),
        payload     : {
            arguments   : Array.prototype.slice.call(args),
        },
        span_guid   : spanGUID,
    });
};

State.prototype.logArgumentsInfo = function(args, spanGUID) {
    if (!this.enabled) {
        return;
    }

    // Ensure args is a true Array, not an Arguments object
    args = Array.prototype.slice.call(args);
    this.logArgumentsWithSpanGUID(spanGUID, "I", args);
    this.logger.info(args);
};
State.prototype.logArgumentsWarn = function(args, spanGUID) {
    if (!this.enabled) {
        return;
    }

    // Ensure args is a true Array, not an Arguments object
    args = Array.prototype.slice.call(args);
    this.logArgumentsWithSpanGUID(spanGUID, "W", args);
    this.logger.warn(args);
};
State.prototype.logArgumentsError = function(args, spanGUID) {
    if (!this.enabled) {
        return;
    }

    // Ensure args is a true Array, not an Arguments object
    args = Array.prototype.slice.call(args);
    this.logArgumentsWithSpanGUID(spanGUID, "E", args);
    this.logger.error(args);
};
State.prototype.logArgumentsFatal = function (args, spanGUID)  {
    if (!this.enabled) {
        return;
    }

    // Ensure args is a true Array, not an Arguments object
    args = Array.prototype.slice.call(args); 
    this.logArgumentsWithSpanGUID(spanGUID, "F", args);
    this.logger.fatal(args);
    this.processAbort();
};

State.prototype.logFormattedInfo = function(args, spanGUID) {
    if (!this.enabled) {
        return;
    }
    throw new Error("NOT_YET_IMPLEMENTED");
};

State.prototype.logFormattedWarn = function(args, spanGUID) {
    if (!this.enabled) {
        return;
    }
    throw new Error("NOT_YET_IMPLEMENTED");
};
State.prototype.logFormattedError = function(args, spanGUID) {
    if (!this.enabled) {
        return;
    }
    throw new Error("NOT_YET_IMPLEMENTED");
};
State.prototype.logFormattedFatal = function(args, spanGUID) {
    if (!this.enabled) {
        return;
    }
    throw new Error("NOT_YET_IMPLEMENTED");
    //this.processAbort();
};

// Javascript doesn't really have a very solid standard on exception objects.
// The code below tries to extract as much information as possible based
// on the common cases of what information may be available.
//
State.prototype.logException = function (e, spanGUID) {
    if (!this.enabled) {
        return;
    }

    var stackFrames = [];
    var lineNumber;
    var filename;

    // Attempt to extract the call stack from the string (correct for 
    // at least Chrome 40, Node.js v0.12).  Note: hooking into V8's 
    // prepareCallStack is a more direct way to get this information but
    // involves overrriding default behaviors of V8-only APIs - may want 
    // to do that eventually, but for now simple string parsing is used.
    // http://stackoverflow.com/questions/11386492/accessing-line-number-in-v8-javascript-chrome-node-js
    //
    if (typeof e.stack === "string") {
        stackFrames = e.stack.split("\n");

        // Assume the string has the form below and try to extract info:
        //      Error: This is an error
        //          at Context.<anonymous> (/.../test/shared_unittests.js:202:30)
        //          ...
        if (stackFrames.length >= 2) {
            var top = stackFrames[1];
            var m;
            if (top.match(/^\s+at\s/) && (m = top.match(/\((.+):([0-9]+):([0-9]+)\)$/))) {
                filename = m[1];
                try {
                    lineNumber = parseInt(m[2]);
                } catch (ignored) {
                }
            }
        }
    }
    

    // Be as specific as we can for the standard exception types:
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error
    //
    // This might be redundant as to what toString() will produce, but
    // that is unclear as what toString() produces is not standardized.
    var exceptionType = "Exception";
    if (e instanceof EvalError) {
        exceptionType = "EvalError";
    } else if (e instanceof RangeError) {
        exceptionType = "RangeError";
    } else if (e instanceof ReferenceError) {
        exceptionType = "ReferenceError";
    } else if (e instanceof SyntaxError) {
        exceptionType = "SyntaxError";
    } else if (e instanceof TypeError) {
        exceptionType = "TypeError";
    } else if (e instanceof URIError) {
        exceptionType = "URIError";
    } else if (e instanceof Error) {
        exceptionType = "Error";
    }

    this.rawLogRecord({
        span_guid       : spanGUID,       // May be undefined
        message         : e.toString(),
        level           : "E",
        filename        : filename,       // May be undefined
        line_number     : lineNumber,     // May be undefined
        payload         : {
            exceptionType : exceptionType,
        },
        stack_frames    : stackFrames,
    });
};

//===========================================================================//
// Events
//===========================================================================//

State.prototype.logEvent = function(name, payload, spanGUID) {
    if (!this.enabled) {
        return;
    }
    this.rawLogRecord({
        stable_name     : name,
        filename        : this.defaultLogFilename(),
        payload         : payload,
        span_guid       : spanGUID,
    });
};

State.prototype.eventWrap = function(name, f) {
    // We *don't* check this.enabled on the outer wrapper. The enabled setting
    // is potentially togglable at runtime.  Conditionally creating the wrapper
    // would be very confusing as later re-enabling the cruntime would not
    // retroactively convert the input function into a wrapper equivalent.
    var self = this;
    return function() {
        if (this.enabled) {
            self.rawLogRecord({
                stable_name : name,
                filename    : self.defaultLogFilename(),
                payload     : {
                    arguments    : arguments,
                    stack_frames : platform.stackTrace(),
                },
            });
        }
        return f.apply(this, arguments);
    };
};

//===========================================================================//
// Spans
//===========================================================================//

// Create the span record
State.prototype.rawSpanBegin = function (name, joinIdKeyValues) {
    if (!this.enabled) {
        return null;
    }

    var record = pool.spanRecords.acquire();
    record.span_guid     = platform.generateGUID();
    record.runtime_guid  = this.runtime.guid;
    record.span_name     = name;
    record.oldest_micros = platform.nowMicros();
    record.youngest_micros = null;
    record.join_ids      = [];

    this.mergeJoinIdMapIntoSpanRecord(record, joinIdKeyValues);
    return record;
};

// Merge a JS map of key-value pairs into the span record's thrift join ids
// structures.  Use this method rather than doing this manually to ensure the
// object pooling is utilized.
State.prototype.mergeJoinIdMapIntoSpanRecord = function(spanRecord, joinIdMap) {
    if (!joinIdMap) {
        return;
    }
    for (var key in joinIdMap) {
        var joinId = pool.traceJoinIds.acquire();
        joinId.TraceKey = key;
        joinId.Value = joinIdMap[key];
        spanRecord.join_ids.push(joinId);
    }
};

// Create the "handle" object for a given span record.
State.prototype.createSpanHandle = function (spanRecord) {
    return span_handle.acquire(this, spanRecord);
};

// Start a new span and return an interface for controlling the span.  The
// second argument is an optional map of join ids.
// 
// var handle = cr.span("my_span", { my_key : "my_value" });
// ...
// handle.end();
//
State.prototype.span = function (name, joinIdKeyValues) {
    var record = this.rawSpanBegin(name, joinIdKeyValues);
    return this.createSpanHandle(record);
};

// Wrap a synchronous function inside a span and return the wrapper function.
// A map of join ids can optionally be passed in as a second argument.  Note
// this will not work as expected with asynchronous functions that signal
// completion via an promise, event, or callback.
//
// function add(x, y) { return x + y; }
//
// var add = cr.spanWrap("add", add);
// var z = add(1, 2);
//
State.prototype.spanWrap = function (name, joinIdKeyValues, f) {
    var self = this;

    if (arguments.length == 2) {
        f = joinIdKeyValues;
        joinIdKeyValues = {};
    }

    return function() {
        var handle = self.span(name, joinIdKeyValues);
        var r;
        try {
            r = f.apply(this, arguments);
        } catch (e) {
            self.logException(e);
            throw e;
        } finally {
            handle.end();
        }
        return r;
    };
};

// Wrap a block of synchronous code inside a span.  The code will be executed
// immediately.  This is an alternative to explicitly surrounding the block
// of code with span creation and end() call that will automatically catch
// and log exceptions before rethrowing them.
//
// var z = 0;
// cr.spanSection("inner_computation", function() { 
//      z = 4 * 2;
// });
//
State.prototype.spanSection = function (name, joinIdKeyValues, f) {
    if (arguments.length === 2) {
        f = joinIdKeyValues;
        joinIdKeyValues = {};
    }

    var handle = this.span(name, joinIdKeyValues);
    var r;
    try {
        r = f();
    } catch (e) {
        this.logException(e);
        throw e;
    } finally {
        handle.end();    
    }
    return r;
};

// A manually created span.
State.prototype.spanManual = function (name, oldestMicros, youngestMicros) {
    if (!this.enabled) {
        return;
    }
    var record = this.rawSpanBegin(name);
    record.oldest_micros = oldestMicros;
    record.youngest_micros = youngestMicros;
    this.pushSpanRecord(record);
};

// Add a span record to the internal buffer
State.prototype.pushSpanRecord = function(record) {
    // Merge in any global join ids -- do this at the end of the span as 
    // this allows some spans that may have been automatically created
    // by the cruntime before the user set the global join ids to still
    // capture those global join ids.
    this.mergeJoinIdMapIntoSpanRecord(record, this.joinIds);

    if (this.spans.length >= this.bufferMaxSpanRecords) {
        // Treat this like a random sampling and replace a record at random.
        // This is not truly random in mathematical sense for a number of reasons,
        // but the assumption this is provides more useful information than 
        // dropping all records once the max is hit.
        var index = Math.floor(this.spans.length * Math.random());
        releaseSpanRecord(this.spans[index]);
        this.spans[index] = record;
    } else {
        this.spans.push(record);
    }
};

//===========================================================================//
// Stats
//===========================================================================//

// Primarily intended for debugging
State.prototype.reportBufferStats = function() {
    return {
        // Current buffer stats
        queued_logs         : this.logs.length,
        queued_spans        : this.spans.length,
        max_log_records     : this.bufferMaxLogRecords,
        max_span_records    : this.bufferMaxSpanRecords,

        // Memory pooling stats
        log_records_allocated  : pool.logRecords.allocationCount,
        log_records_acquired   : pool.logRecords.acquireCount,
        log_records_released   : pool.logRecords.releaseCount,
        log_records_active     : pool.logRecords.allocationCount - pool.logRecords.freeList.length,

        span_records_allocated : pool.spanRecords.allocationCount,
        span_records_acquired  : pool.spanRecords.acquireCount,
        span_records_released  : pool.spanRecords.releaseCount,
        span_records_active    : pool.spanRecords.allocationCount - pool.spanRecords.freeList.length,

        join_ids_allocated     : pool.traceJoinIds.allocationCount,
        join_ids_acquired      : pool.traceJoinIds.acquireCount,
        join_ids_released      : pool.traceJoinIds.releaseCount,
        join_ids_active        : pool.traceJoinIds.allocationCount - pool.traceJoinIds.freeList.length,
    };
};

//===========================================================================//
// Exports
//===========================================================================//

module.exports = State;
