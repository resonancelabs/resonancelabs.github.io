var rbuild  = require("node/tools/rbuild"),
    path    = require("path");

var plugins = rbuild.Plugins;
var build = new rbuild.Build();

var repoDir = path.normalize(path.join(process.env.GOPATH, ".."));
var publishDir = path.join(repoDir, "/static/resonancelabs.github.io/traceguide/dist/preview/");

build.task("default");

//
// Publish a distributable package to resonancelabs.github.io
//
// TODO: eventually copy a cruntime-node-x.x.x.tar.gz as well as 
// updating "-current.tar.gz".
//
build.task("publish")
    .describe("copies the current code to the public distribution")
    .deps("publish-copy", "publish-commit")

build.task("publish-copy")
    .command("git ls-files | tar cfz dist/cruntime-common-current.tar.gz -T -")
    .spawn("cp", "dist/cruntime-common-current.tar.gz", publishDir);

build.task("publish-commit")
    .cwd(publishDir)
    .spawn("git add .")
    .spawn(["git", "commit", "-m", "'publish cruntime-common'"])
    .spawn("git push origin master");


build.start("default");

