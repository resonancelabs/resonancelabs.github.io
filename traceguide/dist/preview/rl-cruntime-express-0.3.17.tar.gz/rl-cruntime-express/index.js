//
// Usage: see README.md
//

var kMaxURLMessageLength = 72;

var lib = {};

lib.requestSpanMiddleware = function(cr, opts) {

    opts = opts || {};

    return function(req, res, next) {

        // Allow the traceguide_session_guid header in case the client wishes to use it
        res.header("Access-Control-Allow-Headers", "traceguide_session_guid");

        // Associate the express span with the request object; replace an existing http span
        // if there is one.
        var httpSpan = cr.spanForObject(res);
        var span = httpSpan.span("express.request");
        cr.spanForObject(res, span);
        
        // An option to set an anonymous user when a true username will not
        // be known.
        if (opts.generate_anonymous_user && httpSpan) {
            var joinIds  = httpSpan.joinIds();
            if (joinIds) {
                var traceguideSessionId = joinIds.traceguide_session_id;
                if (traceguideSessionId) {
                    traceguideSessionId = traceguideSessionId.replace(/^rt\-/,"");
                    sp.joinIds({
                        end_user_id : "user-" + traceguideSessionId,
                    });
                }
            }
        }

        var payload = {
            body            : req.body,
            params          : req.params,
            xhr             : req.xhr,
        };
        if (req.ip) {
            payload.ip = req.ip;
        }
        if (req.ips && req.ips.length) {
            payload.ips = req.ips;
        }
        if (req.socket) {
            payload.socket = {
                remote_address : req.socket.remoteAddress,
                remote_port    : req.socket.remotePort,
                local_address  : req.socket.localAddress,
                local_port     : req.socket.localPort,
            };
        }

        var message = "Base URL: " + req.originalUrl;
        if (message.length > kMaxURLMessageLength) {
            message = message.substr(0, kMaxURLMessageLength - 1) + "…";
        }
        span.logRecord({
            message : message,
            payload : payload,
        });
        
        function endExpressSpan() {
            // The route is not ready until this point as the middleware is intended to
            // be injected before express route dispatching.
            if (req.route) {
                span.logRecord({
                    stable_name : "express.route",
                    message     : (String(req.route.regexp) || req.route.path),
                    payload     : req.route,
                });
                span.name("express.request: " + req.route.path);
                span.event("cr/span_attributes", {
                    route_path  : req.route.path,
                });
            } else {
                var baseUrl = req.originalUrl.split("?")[0];
                span.event("cr/span_attributes", {
                    short_url   : baseUrl,
                });
            }

            // Set the user id if it is in the session
            if (req.session && req.session.user) {
                span.event("cr/span_attributes", {
                    "user_id": req.session.user.id,
                });
            } 
            span.end();
        }
        res.on("close",  endExpressSpan);
        res.on("finish", endExpressSpan);

        cr.setActiveSpan(span, this, null, function() {
            next.apply(this);
        });
    };
};

module.exports = lib;
