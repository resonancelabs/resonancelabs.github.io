# rl-cruntime-express

cruntime support for the Node.js "Express" web framework.

## Instrumentation

At the top of any file to instrument, include the package.

```js
var cr = require("rl-cruntime-node");
var cr_express = require("rl-cruntime-express");
```

In your app's primary middleware chain, plug the `cr_express.requestSpanMiddleware` in (a) as early as possible, but (b) after cookies are parsed out of the `req` object.

```js
app.use ...
app.use(express.cookieParser());
app.use(cr_express.requestSpanMiddleware(cr));
app.use ...
```
