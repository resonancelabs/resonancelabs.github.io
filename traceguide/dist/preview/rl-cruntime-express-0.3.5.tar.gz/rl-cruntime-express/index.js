//
// Usage: see README.md
//

var kMaxURLMessageLength = 72;

var lib = {};

lib.requestSpanMiddleware = function(cr, opts) {

    opts = opts || {};

    return function(req, res, next) {

        // Allow the traceguide_session_guid header in case the client wishes to use it
        res.header("Access-Control-Allow-Headers", "traceguide_session_guid");

        // Inject some knowledge of our http instrumentation and pick up that span if it exists.
        var httpSpan = res.__cr_http_span;
        var sp = (httpSpan || cr).span("express_request");
        res.express_span = sp;
        
        // An option to set an anonymous user when a true username will not
        // be known.
        if (opts.generate_anonymous_user && httpSpan) {
            var joinIds  = httpSpan.joinIds();
            var traceguideSessionId = joinIds.traceguide_session_id;
            if (traceguideSessionId) {
                traceguideSessionId = traceguideSessionId.replace(/^rt\-/,"");
                sp.joinIds({
                    end_user_id : "user-" + traceguideSessionId,
                });
            }
        }

        var payload = {
            body            : req.body,
            params          : req.params,
            xhr             : req.xhr,
        };
        if (req.ip) {
            payload.ip = req.ip;
        }
        if (req.ips && req.ips.length) {
            payload.ips = req.ips;
        }
        if (req.socket) {
            payload.socket = {
                remote_address : req.socket.remoteAddress,
                remote_port    : req.socket.remotePort,
                local_address  : req.socket.localAddress,
                local_port     : req.socket.localPort,
            };
        }

        var message = "Base URL: " + req.originalUrl;
        if (message.length > kMaxURLMessageLength) {
            message = message.substr(0, kMaxURLMessageLength - 1) + "…";
        }
        sp.logRecord({
            message : message,
            payload : payload,
        });
        
        function endExpressSpan() {
            // The route is not ready until this point as the middleware is intended to
            // be injected before express route dispatching.
            if (req.route) {
                sp.logRecord({
                    stable_name : "express.route",
                    message     : (String(req.route.regexp) || req.route.path),
                    payload     : req.route,
                });
                sp.name("express_request: " + req.route.path);

                // Let the entire trace know what the express path was (since
                // it provides so much context).
                sp.event("cr/span_attributes", {
                    route_path : req.route.path,
                });
            }

            // Set the user id if it is in the session
            if (req.session && req.session.user) {
                sp.event("cr/span_attributes", {
                    "user_id": req.session.user.id,
                });
            } 
            sp.end();
        }
        res.on("close",  endExpressSpan);
        res.on("finish", endExpressSpan);

        cr.setActiveSpan(sp, this, null, function() {
            next.apply(this);
        });
    };
};

module.exports = lib;
